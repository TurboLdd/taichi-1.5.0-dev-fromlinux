var searchData=
[
  ['general_20considerations_0',['General considerations',['../general_considerations.html',1,'index']]]
];
