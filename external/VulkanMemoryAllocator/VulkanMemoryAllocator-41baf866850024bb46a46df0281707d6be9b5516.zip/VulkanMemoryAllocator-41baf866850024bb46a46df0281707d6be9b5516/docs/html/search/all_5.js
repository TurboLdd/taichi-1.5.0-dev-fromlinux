var searchData=
[
  ['flags_0',['flags',['../struct_vma_allocator_create_info.html#a392ea2ecbaff93f91a7c49f735ad4346',1,'VmaAllocatorCreateInfo::flags()'],['../struct_vma_allocation_create_info.html#add09658ac14fe290ace25470ddd6d41b',1,'VmaAllocationCreateInfo::flags()'],['../struct_vma_pool_create_info.html#a8405139f63d078340ae74513a59f5446',1,'VmaPoolCreateInfo::flags()'],['../struct_vma_defragmentation_info.html#a3e23080c978ecf3abb3180f5b2069da7',1,'VmaDefragmentationInfo::flags()'],['../struct_vma_virtual_block_create_info.html#aaab9bf7e2d228c02ab6d90a72a6e6912',1,'VmaVirtualBlockCreateInfo::flags()'],['../struct_vma_virtual_allocation_create_info.html#ab10e16956cc4bf20ced9de77d1129ea4',1,'VmaVirtualAllocationCreateInfo::flags()']]]
];
