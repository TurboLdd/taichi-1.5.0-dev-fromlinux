var searchData=
[
  ['vmaallocationcreateflagbits_0',['VmaAllocationCreateFlagBits',['../group__group__alloc.html#gad9889c10c798b040d59c92f257cae597',1,'vk_mem_alloc.h']]],
  ['vmaallocatorcreateflagbits_1',['VmaAllocatorCreateFlagBits',['../group__group__init.html#ga4f87c9100d154a65a4ad495f7763cf7c',1,'vk_mem_alloc.h']]],
  ['vmadefragmentationflagbits_2',['VmaDefragmentationFlagBits',['../group__group__alloc.html#ga6552a65b71d16f378c6994b3ceaef50c',1,'vk_mem_alloc.h']]],
  ['vmadefragmentationmoveoperation_3',['VmaDefragmentationMoveOperation',['../group__group__alloc.html#gada9e3861caf96f08894b0bcc160ec257',1,'vk_mem_alloc.h']]],
  ['vmamemoryusage_4',['VmaMemoryUsage',['../group__group__alloc.html#gaa5846affa1e9da3800e3e78fae2305cc',1,'vk_mem_alloc.h']]],
  ['vmapoolcreateflagbits_5',['VmaPoolCreateFlagBits',['../group__group__alloc.html#ga9a7c45f9c863695d98c83fa5ac940fe7',1,'vk_mem_alloc.h']]],
  ['vmavirtualallocationcreateflagbits_6',['VmaVirtualAllocationCreateFlagBits',['../group__group__virtual.html#ga2e9c64d405b14156fea7e10c4ad06cb6',1,'vk_mem_alloc.h']]],
  ['vmavirtualblockcreateflagbits_7',['VmaVirtualBlockCreateFlagBits',['../group__group__virtual.html#ga88bcf8c1cd3bb1610ff7343811c65bca',1,'vk_mem_alloc.h']]]
];
