var searchData=
[
  ['statistics_0',['Statistics',['../statistics.html',1,'index']]],
  ['staying_20within_20budget_1',['Staying within budget',['../staying_within_budget.html',1,'index']]]
];
