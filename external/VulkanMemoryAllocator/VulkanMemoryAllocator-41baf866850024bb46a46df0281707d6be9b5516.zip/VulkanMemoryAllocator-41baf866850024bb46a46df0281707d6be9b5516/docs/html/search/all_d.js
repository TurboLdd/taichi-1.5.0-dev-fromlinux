var searchData=
[
  ['recommended_20usage_20patterns_0',['Recommended usage patterns',['../usage_patterns.html',1,'index']]],
  ['requiredflags_1',['requiredFlags',['../struct_vma_allocation_create_info.html#a9166390303ff42d783305bc31c2b6b90',1,'VmaAllocationCreateInfo']]],
  ['resource_20aliasing_20_28overlap_29_2',['Resource aliasing (overlap)',['../resource_aliasing.html',1,'index']]]
];
