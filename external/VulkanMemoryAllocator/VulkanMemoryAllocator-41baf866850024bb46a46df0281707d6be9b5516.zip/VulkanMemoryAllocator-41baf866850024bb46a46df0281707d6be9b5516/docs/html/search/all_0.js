var searchData=
[
  ['alignment_0',['alignment',['../struct_vma_virtual_allocation_create_info.html#a9d19709872fc1904a105079e1c885821',1,'VmaVirtualAllocationCreateInfo']]],
  ['allocation_20names_20and_20user_20data_1',['Allocation names and user data',['../allocation_annotation.html',1,'index']]],
  ['allocationbytes_2',['allocationBytes',['../struct_vma_statistics.html#a21db06eba3422f87a2b4b4703d879c16',1,'VmaStatistics']]],
  ['allocationcount_3',['allocationCount',['../struct_vma_statistics.html#ab0ff76e50f58f9f54b6f265e5bf5dde2',1,'VmaStatistics']]],
  ['allocationsizemax_4',['allocationSizeMax',['../struct_vma_detailed_statistics.html#a06b2add24eed3449a66ff151979a0201',1,'VmaDetailedStatistics']]],
  ['allocationsizemin_5',['allocationSizeMin',['../struct_vma_detailed_statistics.html#a6fb397e7487e10f2a52e241577d2a2b8',1,'VmaDetailedStatistics']]],
  ['allocationsmoved_6',['allocationsMoved',['../struct_vma_defragmentation_stats.html#aefeabf130022008eadd75999478af3f9',1,'VmaDefragmentationStats']]]
];
