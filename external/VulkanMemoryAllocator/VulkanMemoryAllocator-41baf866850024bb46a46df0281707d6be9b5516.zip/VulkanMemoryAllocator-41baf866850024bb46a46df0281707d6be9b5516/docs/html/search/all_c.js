var searchData=
[
  ['quick_20start_0',['Quick start',['../quick_start.html',1,'index']]]
];
