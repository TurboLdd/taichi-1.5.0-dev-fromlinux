var searchData=
[
  ['memory_20allocation_0',['Memory allocation',['../group__group__alloc.html',1,'']]]
];
