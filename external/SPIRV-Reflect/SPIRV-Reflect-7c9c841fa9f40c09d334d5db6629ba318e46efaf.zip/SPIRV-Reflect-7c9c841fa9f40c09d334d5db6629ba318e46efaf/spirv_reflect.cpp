//
// This file exists to force compiling spirv_reflect.c as C++.
//
#include "spirv_reflect.c"